PHP MVC Books - Simple example (OOP + MVC + Exception Handling + Logging)
-----------------------------------------------------------
Struktur folder ada di dalam file ZIP. Untuk menggunakan:
1. Jalankan `composer dump-autoload` di root proyek setelah mengekstrak.
2. Jalankan pada server PHP (built-in: `php -S localhost:8000`) atau deploy ke hosting yang mendukung PHP.
3. Akses index.php di browser.
