<?php
namespace App\Controllers;

use App\Models\Book;
use Throwable;

class BookController {
    public function addBook(string $title, string $author) {
        try {
            $book = new Book($title, $author);
            $this->renderView($book);
        } catch (Throwable $e) {
            // Logging error ke file
            file_put_contents(__DIR__ . '/../../error.log',
                date('Y-m-d H:i:s') . ' - ' . $e->getMessage() . PHP_EOL,
                FILE_APPEND
            );
            echo "<p style='color:red;'>Terjadi error: " . $e->getMessage() . "</p>";
        } finally {
            echo "<p><i>Proses penambahan buku selesai.</i></p>";
        }
    }

    private function renderView(Book $book) {
        require __DIR__ . '/../Views/book_view.php';
    }
}
