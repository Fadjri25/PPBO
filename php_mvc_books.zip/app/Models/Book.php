<?php
namespace App\Models;

class BookException extends \Exception {}

class Book {
    private string $title;
    private string $author;

    public function __construct(string $title, string $author) {
        if (empty($title) || empty($author)) {
            throw new BookException("Judul dan pengarang tidak boleh kosong!");
        }
        $this->title = $title;
        $this->author = $author;
    }

    public function getTitle(): string {
        return $this->title;
    }

    public function getAuthor(): string {
        return $this->author;
    }
}
