<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Tambah Buku</title>
</head>
<body>
<h2>Form Tambah Buku</h2>
<form method="post" action="">
    Judul Buku: <input type="text" name="title"><br><br>
    Pengarang: <input type="text" name="author"><br><br>
    <button type="submit">Tambah Buku</button>
</form>
<hr>
