<h3>Data Buku Berhasil Ditambahkan!</h3>
<p><b>Judul:</b> <?= htmlspecialchars($book->getTitle()); ?></p>
<p><b>Pengarang:</b> <?= htmlspecialchars($book->getAuthor()); ?></p>
</body>
</html>
