<?php
require __DIR__ . '/vendor/autoload.php';

use App\Controllers\BookController;

$controller = new BookController();

// Menampilkan form
require __DIR__ . '/app/Views/book_form.php';

// Jika ada input dari form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['title'], $_POST['author'])) {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $controller->addBook($title, $author);
}
